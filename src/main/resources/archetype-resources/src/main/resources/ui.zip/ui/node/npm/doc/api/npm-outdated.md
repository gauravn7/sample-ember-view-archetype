npm-outdated(3) -- Check for outdated packages
==============================================

## SYNOPSIS

    npm.commands.outdated([packages,] callback)

## DESCRIPTION

This command will check the registry to see if the specified packages are
currently outdated.

If the 'packages' parameter is left out, npm will check all packages.
